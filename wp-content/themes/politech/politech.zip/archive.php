<?php get_header('archive'); ?>

<?php $requisicao = get_queried_object(); ?>

    <?php print_r($requisicao) ?>

    archive.php<br/><br/>


<?php get_footer(); ?>