﻿<footer id="footer">
    <div class="container">
        <div class="row text-center">
            <div class="footer-content">
                <!--
                <div class="wow animated fadeInDown">
                    <p>Fique por dentro de nossas novidaslider
                <form action="" method="post" class="subscribe-form wow animated fadeInUp">
                    <div class="input-field">
                        <input type="email" name="newsletter-email" class="subscribe form-control" placeholder="Seu email...">
                        <button type="submit" name="submit" value="newsletter" class="submit-icon">
                            <i class="fa fa-paper-plane fa-lg"></i>
                        </button>
                    </div>
                </form>
                -->
                <div class="footer-social">
                    <ul>
                        <li class="wow animated zoomIn"><a target="_blank" style="color: #7f7f7f" href="https://www.facebook.com/politechpc/"><i class="fa fa-facebook fa-3x"></i></a></li>
                        <!--<li class="wow animated zoomIn" data-wow-delay="0.3s"><a href="#"><i
                                    class="fa fa-twitter fa-3x"></i></a></li>
                        <li class="wow animated zoomIn" data-wow-delay="0.6s"><a href="#"><i
                                    class="fa fa-skype fa-3x"></i></a></li>-->
                        <li class="wow animated zoomIn" data-wow-delay="0.9s"><a target="_blank" style="color: #7f7f7f" href="https://www.instagram.com/politechjr/"><i
                                    class="fa fa-instagram fa-3x"></i></a></li>
                        <li class="wow animated zoomIn" data-wow-delay="1.2s"><a target="_blank" style="color: #7f7f7f" href="https://www.youtube.com/channel/UCuvbqo3cY_O4dcjKmt4qLwQ"><i
                                    class="fa fa-youtube fa-3x"></i></a></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</footer>

<!-- Essential jQuery Plugins
    ================================================== -->
<!-- Main jQuery -->
<script src="<?php echo get_template_directory_uri() ?>/js/jquery-1.11.1.min.js"></script>
<!-- Twitter Bootstrap -->
<script src="<?php echo get_template_directory_uri() ?>/js/bootstrap.min.js"></script>
<!-- Single Page Nav -->
<script src="<?php echo get_template_directory_uri() ?>/js/jquery.singlePageNav.min.js"></script>
<!-- jquery.fancybox.pack -->
<script src="<?php echo get_template_directory_uri() ?>/js/jquery.fancybox.pack.js"></script>
<!-- Owl Carousel -->
<script src="<?php echo get_template_directory_uri() ?>/js/owl.carousel.min.js"></script>
<!-- jquery easing -->
<script src="<?php echo get_template_directory_uri() ?>/js/jquery.easing.min.js"></script>
<!-- Fullscreen slider -->
<script src="<?php echo get_template_directory_uri() ?>/js/jquery.slitslider.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/js/jquery.ba-cond.min.js"></script>
<!-- onscroll animation -->
<script src="<?php echo get_template_directory_uri() ?>/js/wow.min.js"></script>
<!-- Custom Functions -->
<script src="<?php echo get_template_directory_uri() ?>/js/main.js"></script>

<?php wp_footer(); ?>

</body>
</html>