<?php get_header('single'); ?>

Página não encontrada

<?php echo $_SERVER['PHP_SELF'] ?>

<?php get_footer(); ?>